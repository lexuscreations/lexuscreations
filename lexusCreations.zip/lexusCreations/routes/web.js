const homeController = require('../app/http/controllers/homeController')
const appStoreController = require('../app/http/controllers/appStoreController')
const projectsController = require('../app/http/controllers/projectsController')
const docsController = require('../app/http/controllers/docsController')
const learningController = require('../app/http/controllers/learningController')
const contactController = require('../app/http/controllers/contactController')
const appDetailController = require('../app/http/controllers/appDetailController')
const downloadController = require('../app/http/controllers/downloadController')

function initRoutes(app) {
    app.get('/', homeController().index)
    app.get('/appStore', appStoreController().index)
    app.get('/projects', projectsController().index)
    app.get('/docs', docsController().index)
    app.get('/learning', learningController().index)
    app.get('/contact', contactController().index)
    app.get('/appDetail:id', appDetailController().index)
    app.get('/download:id', downloadController().index)
}

module.exports = initRoutes