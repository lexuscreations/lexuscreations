function docsController() {
    return {
        index(req, res) {
            return res.render('pages/docs', { title: "Documentation" })
        }
    }
}

module.exports = docsController