function learningController() {
    return {
        index(req, res) {
            return res.render('pages/learning', { title: "Learning" })
        }
    }
}

module.exports = learningController