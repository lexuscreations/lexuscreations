let appsConsiderLinkTemplate = ["batch", "cpp", "python", "tableApp"]
let appsConsiderLinkAndroid = ["table"]

function appDetailController() {
    return {
        index(req, res) {
            let appDetailName = req.params.id
            let appNameGet = appDetailName.slice(1)
            if (appsConsiderLinkTemplate.includes(appNameGet)) {
                let path = "pages/appDetails/templateApp/" + appNameGet + "App"
                return res.render(path, { pageNamme: appNameGet, title: appNameGet })
            } else if (appsConsiderLinkAndroid.includes(appNameGet)) {
                let path = "pages/appDetails/androidApp/" + appNameGet + "App"
                return res.render(path, { pageNamme: appNameGet, title: appNameGet })
            } else {
                res.status(404).render('errors/404', { reqUrl: req.url, title: req.url })
            }
        }
    }
}
module.exports = appDetailController