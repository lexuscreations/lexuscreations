function appStoreController() {
    return {
        index(req, res) {
            return res.render('pages/appStore', { title: "AppStore" })
        }
    }
}

module.exports = appStoreController