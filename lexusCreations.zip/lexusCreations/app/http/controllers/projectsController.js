function projectsController() {
    return {
        index(req, res) {
            return res.render('pages/projects', { title: "Projects" })
        }
    }
}

module.exports = projectsController