function contactController() {
    return {
        index(req, res) {
            return res.render('pages/contact', { title: "Contact" })
        }
    }
}

module.exports = contactController