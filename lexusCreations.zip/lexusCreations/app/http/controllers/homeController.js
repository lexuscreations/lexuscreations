function homeController() {
    return {
        index(req, res) {
            return res.render('home', { title: "Home" })
        }
    }
}

module.exports = homeController