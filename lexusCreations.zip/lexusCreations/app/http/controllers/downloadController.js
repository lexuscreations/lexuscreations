const path = require('path')

const files = {
    fileDetails: [{
        id: ':batchbat',
        path: 'apps/TemplateApp/batchApp/LexusTemplateApp.bat'
    }, {
        id: ':batchtxt',
        path: 'apps/TemplateApp/batchApp/LexusTemplateAppCodeBatch.txt'
    }, {
        id: ':batchzip',
        path: 'apps/TemplateApp/batchApp/LexusTemplateApp.zip'
    }, {
        id: ':cppexe',
        path: 'apps/TemplateApp/cppApp/LexusTemplateAppCpp.exe'
    }, {
        id: ':cpptxt',
        path: 'apps/TemplateApp/cppApp/LexusTemplateAppCodeCpp.txt'
    }, {
        id: ':cppcode',
        path: 'apps/TemplateApp/cppApp/LexusTemplateApp.cpp'
    }, {
        id: ':pythonexe',
        path: 'apps/TemplateApp/pythonApp/LexusTemplateAppPy.exe'
    }, {
        id: ':pythontxt',
        path: 'apps/TemplateApp/pythonApp/LexusTemplateAppCodePy.txt'
    }, {
        id: ':pythoncode',
        path: 'apps/TemplateApp/pythonApp/LexusTemplateApp.py'
    }, {
        id: ':pythonsetup',
        path: 'apps/TemplateApp/pythonApp/LexusTemplateAppSetup.exe'
    }, {
        id: ':resumepdf',
        path: 'docsFiles/Resume.pdf'
    }, {
        id: ':tableapptxt',
        path: 'apps/AndroidApp/MultiplicationTableApp/LexusMultiplicationTableAppAndroidStudioAppFiles.zip'
    }, {
        id: ':tableappapk',
        path: 'apps/AndroidApp/MultiplicationTableApp/LexusTableApp.apk'
    }]
};

function downloadController() {
    return {
        index(req, res) {

            switch (req.params.id) {

                case files.fileDetails[0].id:
                    res.download(path.resolve(__dirname, '../../../public', files.fileDetails[0].path))
                    break;

                case files.fileDetails[1].id:
                    res.download(path.resolve(__dirname, '../../../public', files.fileDetails[1].path))
                    break;

                case files.fileDetails[2].id:
                    res.download(path.resolve(__dirname, '../../../public', files.fileDetails[2].path))
                    break;

                case files.fileDetails[3].id:
                    res.download(path.resolve(__dirname, '../../../public', files.fileDetails[3].path))
                    break;

                case files.fileDetails[4].id:
                    res.download(path.resolve(__dirname, '../../../public', files.fileDetails[4].path))
                    break;

                case files.fileDetails[5].id:
                    res.download(path.resolve(__dirname, '../../../public', files.fileDetails[5].path))
                    break;

                case files.fileDetails[6].id:
                    res.download(path.resolve(__dirname, '../../../public', files.fileDetails[6].path))
                    break;

                case files.fileDetails[7].id:
                    res.download(path.resolve(__dirname, '../../../public', files.fileDetails[7].path))
                    break;

                case files.fileDetails[8].id:
                    res.download(path.resolve(__dirname, '../../../public', files.fileDetails[8].path))
                    break;

                case files.fileDetails[9].id:
                    res.download(path.resolve(__dirname, '../../../public', files.fileDetails[9].path))
                    break;

                case files.fileDetails[10].id:
                    res.download(path.resolve(__dirname, '../../../public', files.fileDetails[10].path))
                    break;

                case files.fileDetails[11].id:
                    res.download(path.resolve(__dirname, '../../../public', files.fileDetails[11].path))
                    break;

                case files.fileDetails[12].id:
                    res.download(path.resolve(__dirname, '../../../public', files.fileDetails[12].path))
                    break;

                default:
                    res.status(404).render('errors/404', { reqUrl: req.url, title: req.url })
            }
        }
    }
}

module.exports = downloadController