// Docs.ejs | ./functions/docs.js | vars - decleration
let snipetHtml = `
    <!DOCTYPE html>
    <html lang="en-US" dir="ltr">
    
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>LexusCreations</title>
        <link rel="shortcut icon" href="./favicon.ico" type="image/x-icon">
        <link rel="stylesheet" href="/css/style.css">
        <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    </head>
    
    <body>
        <div class="container">
            <header>
                <nav></nav>
            </header>
            <main></main>
            <footer></footer>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
        <script src="./js/script.js"></script>
    </body>
    
    </html>
    `

let snipetCss = `
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        scroll-behavior: smooth;
        transition: all 0.2s ease-in-out;
    }
    
    html {
        font-size: 16px;
        -webkit-font-smoothing: antialiased;
    }
    
    body {
        font-family: 'Roboto', sans-serif;
        background: black !important;
    }
    `

let snipetJs = `
    // Press F12 In Your Browser Window To Open Console
    console.log("JsEnable's");
    `

let snipetScroll = `
    ::-webkit-scrollbar {
        width: 10px;
    }
    
     ::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 10px;
    }
    
     ::-webkit-scrollbar-thumb {
        background: green;
        border-radius: 10px;
    }
    
     ::-webkit-scrollbar-thumb:hover {
        background: #013b01;
    }
    `

let snipetSelect = `
    h1::selection {
        color: red;
        background: yellow;
    }
    
    h1::-moz-selection {
        color: red;
        background: yellow;
    }
    `

let snipetFullScrenn = `
    // FullScreen Toggle Function - Needed Jquery
    
    reqFullscreen = FullScrElement.requestFullscreen || FullScrElement.webkitRequestFullScreen || FullScrElement.mozRequestFullScreen || FullScrElement.msRequestFullScreen
    
    function fullScreenApi() {
        return document.fullscreenElement || document.webkitfullscreenElement || document.mozfullscreenElement || document.msfullscreenElement
    }
    
    $(".FullScreenBtn").click(() => {
        if (fullScreenApi()) {
            document.exitFullscreen().catch((e) => {
                console.log(e)
            })
        } else {
            reqFullscreen.call(FullScrElement)
        }
    })
    `

let snipetPreventCutCopyPasteRightClick = `
    $(document).ready(function() {
    
        //Prevent Cut Copy Paste
        $("html").bind('cut copy paste', function(e) {
                e.preventDefault();
        })
    
        //Prevent Right Click
        $("html").on("contextmenu", function(e) {
            return false;
        })
    
    })
    `

let snipetPreventInspectConsoleViewSource = `
    //Prevent inspect console viewSource
    document.onkeydown = function(e) {
        // F12 = inspect menu
        if (e.keyCode == 123) {
            return false;
        }
    
        // ctrl+shift+i = element inspect menu
        if (e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
            return false;
        }
    
        // ctrl+shift+j = console inspect menu 
        if (e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
            return false;
        }
    
        // ctrl+u = view source
        if (e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
            return false;
        }
    }
    `

let snipetPreLoader = `
    <!--Css-->
    <style>
    .loaderouter {
        position: absolute;
        top: 42%;
        left: 45%;
        transform: translate(-50%, -50%);
        border: 16px solid #f3f3f3;
        border-top: 16px solid #3498db;
        border-bottom: 16px solid #3498db;
        border-radius: ;
        width: 120px;
        height: 120px;
        animation: spin 2s linear infinite;
    }
    
    @keyframes spin {
        0% {
            transform: rotate(0deg);
        }
        100% {
            transform: rotate(360deg);
        }
    }
    
    .loaderinner1 {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        border: 16px solid #f3f3f3;
        border-top: 16px solid #3498db;
        border-bottom: 16px solid #3498db;
        border-radius: 50%;
        width: 80px;
        height: 80px;
        animation: spinn 2s linear infinite;
    }
    
    @keyframes spinn {
        0% {
            transform: rotate(360deg);
        }
        100% {
            transform: rotate(0deg);
        }
    }
    </style>
    
    <!--Html-->
    <body onload="myFunction()">
        <div class="loaderouter" id="loaderouter">
            <div class="loaderinner1" id="loaderinner1"></div>
        </div>
        <script type="text/javascript">
            var preloader = document.getElementById('loaderouter');
    
            function myFunction() {
                preloader.style.display = 'none';
            }
        </script>
    </body>
    `