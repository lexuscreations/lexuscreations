$(document).ready(() => {

    $('.pn').click(() => {
        let idcur = "#" + event.target.id
        if ($($(idcur).next()).hasClass('pn-active')) {
            $($(idcur).next()).removeClass('pn-active')
            $(idcur).removeClass("bg-info")
        } else {
            $($(idcur).next()).addClass('pn-active')
            $(idcur).addClass("bg-info")
        }
    })

    $('a[data-reffer]').click(() => {
        let checkid = $("#" + event.target.id).attr("data-reffer")
        let clickednod = $("#" + checkid)
        $('.p').not(clickednod).removeClass('p-active')
        $('a.p-activeCaller').removeClass('p-activeCaller')
        $($('.pn').next()).removeClass('pn-active')
        $('.pn').removeClass("bg-info")

        let checkidNes = $("#" + event.target.id).attr("data-refferNes")
        if (checkidNes == "yes") {
            $(".2tab1Nes").addClass("p-active")
        } else {
            $(".2tab1Nes").removeClass("p-active")
        }

        if ((clickednod).hasClass('p-active')) {
            $(clickednod).removeClass('p-active')
            $("#" + event.target.id).removeClass('p-activeCaller')
        } else {
            $(clickednod).addClass('p-active')
            $("#" + event.target.id).addClass('p-activeCaller')
        }
        $(".htmlCodeSnipet").text(snipetHtml)
        $(".cssCodeSnipet").text(snipetCss)
        $(".jsCodeSnipet").text(snipetJs)
        $(".selectCodeSnipet").text(snipetSelect)
        $(".scrollCodeSnipet").text(snipetScroll)
        $(".fullScreenCodeSnipet").text(snipetFullScrenn)
        $(".preventCutCopyPasteRightClickCodeSnipet").text(snipetPreventCutCopyPasteRightClick)
        $(".preventInspectConsoleViewSourceCodeSnipet").text(snipetPreventInspectConsoleViewSource)
        $(".PreLoaderSourceCodeSnipet").text(snipetPreLoader)
    })

    $(".subMenu").click(() => {
        let clickedId = "#" + event.target.id
        $('.pn').removeClass("bg-info")
        $('a.subMenuNes').removeClass('active')
        $($('a.subMenuNes').next()).removeClass('activeMenu')
        $('a').removeClass('p-activeCaller')
        $($('.pn').next()).removeClass('pn-active')
        $('.p').removeClass('p-active')
        if ($(clickedId).hasClass('active')) {
            $(clickedId).removeClass('active')
            $($(clickedId).next()).removeClass('activeMenu')
            $(clickedId + ' i.fa-sort-down').css({ "transform": "rotate(0deg)" })
            $('a.subMenuNes' + ' i.fa-sort-down').css({ "transform": "rotate(0deg)" })
        } else {
            $('a.subMenu').removeClass('active')
            $($('a.subMenu').next()).removeClass('activeMenu')
            $(clickedId).addClass('active')
            $($(clickedId).next()).addClass('activeMenu')
            $(clickedId + ' i.fa-sort-down').css({ "transform": "rotate(180deg)" })
            $('a.subMenuNes' + ' i.fa-sort-down').css({ "transform": "rotate(0deg)" })
        }
    })

    $(".subMenuNes").click(() => {
        let clickedIdNes = "#" + event.target.id
        $($('.pn').next()).removeClass('pn-active')
        if ($(clickedIdNes).hasClass('active')) {
            $(clickedIdNes).removeClass('active')
            $($(clickedIdNes).next()).removeClass('activeMenu')
            $(clickedIdNes + ' i.fa-sort-down').css({ "transform": "rotate(0deg)" })
        } else {
            $('a.subMenuNes').removeClass('active')
            $($('a.subMenuNes').next()).removeClass('activeMenu')
            $(clickedIdNes).addClass('active')
            $($(clickedIdNes).next()).addClass('activeMenu')
            $(clickedIdNes + ' i.fa-sort-down').css({ "transform": "rotate(180deg)" })
        }
    })

    var ztxt = new Ztextify(".forZtext", {
        depth: "30px",
        layers: 1,
        fade: true,
        direction: "forwards",
        event: "pointer",
        eventRotation: "25deg"
    });

})