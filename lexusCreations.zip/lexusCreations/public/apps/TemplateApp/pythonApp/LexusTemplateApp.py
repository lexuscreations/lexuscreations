# Import Dependencies Section
import os
import re
import sys
import time

# Variables Decleration Section
projectName = ""
loopWhileTempVar = "run"

'''Regular Expression'''
windowsCorrectFolderNamePatern = r'^(?!(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.[^.]*)?$)[^<>:"/\\|?*\x00-\x1F]*[^<>:"/\\|?*\x00-\x1F\ .]$'

'''Layouts - Html / Css / Js'''
htmlLayout = '''
<!DOCTYPE html>
<html lang="en-US">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LexusCreations</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <header>
            <nav>

            </nav>
        </header>
        <main>

        </main>
        <footer></footer>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
</body>

</html>
'''
cssLayout = '''
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    scroll-behavior: smooth;
    transition: all 0.2s ease-in-out;
}

html {
    font-size: 16px;
    -webkit-font-smoothing: antialiased;
}

body {
    font-family: 'Roboto', sans-serif;
    background: black !important;
}
'''
jsLayout = '''
console.log("jsEnable's");
'''

# Function Decleration Defination Section
def msgShowFunction(msg,rangeValue):
    for i in range(1,rangeValue):
        os.system("cls")
        print(msg + " \n" + "Exit In " + str(rangeValue-i))
        time.sleep(1)
    
    os.system("cls")
    sys.exit()

def fileCreationFunction(fileName,fileContent):
    try:
        fileHandler = open(fileName, "w")
        fileHandler.write(fileContent)
    except:
        msgShowFunction("Something went wrong when writing to the file" + fileName, 11)
    finally:
        fileHandler.close()

# Clearing Screen Before Programm Execution
os.system("cls")

# Getting Folder Name From User In projectName Variable
while(loopWhileTempVar != "exit"):
    projectName = str(input("Enter Project Name: "))
    os.system("cls")
    itmes = os.listdir()
    sameNameFound = None
    for item in itmes:
        if item == projectName:
            sameNameFound = "Found"
    regexResult = re.search(windowsCorrectFolderNamePatern, projectName)
    if sameNameFound == "Found":
        os.system("cls")
        print("OS Error - Same Name File Already Exists")
    else:
        if regexResult:
            loopWhileTempVar = "exit"
        else:
            os.system("cls")
            print("OS Error - Plz Enter Valid Name")

os.mkdir(projectName)
os.chdir(projectName)
fileCreationFunction("index.html",htmlLayout)
os.makedirs("css")
os.chdir("css")
fileCreationFunction("style.css",cssLayout)
os.chdir("../")
os.makedirs("js")
os.chdir("js")
fileCreationFunction("script.js",jsLayout)

os.chdir("../")
dirFiles = os.listdir()
for dirFile in dirFiles:
    if os.path.isfile(dirFile):
        print(dirFile)
        time.sleep(0.1)
    elif os.path.isdir(dirFile):
        print(dirFile)
        time.sleep(0.1)
        os.chdir(dirFile)
        dirFilesNes = os.listdir()
        for dirFilesNesFiles in dirFilesNes:
            print(dirFilesNesFiles)
            time.sleep(0.1)
        os.chdir("../")

time.sleep(1)
msgShowFunction("\nSuccess!", 6)