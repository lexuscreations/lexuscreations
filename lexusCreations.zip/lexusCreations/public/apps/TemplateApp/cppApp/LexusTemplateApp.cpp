// For Input/Output
#include <iostream>
// For FileHendling
#include <fstream>
// For Surfing In Directories
#include <dirent.h>
// For Every Function Include The Above One's
using namespace std;
// For Formating Time
#include <time.h>
// For Work With Windows Files Statistics
#include <sys/stat.h>
// For Dealing With Files
#include <filesystem>
// For Dealing With System Like Sleep Command
#include <windows.h>
#include <stdlib.h>

// Functions Definition
void timePrintFunction(char fileNameParam[]) {
    struct _stat buf;
    string err;
    int result;
    char timebuf[26];
    result = _stat( fileNameParam, &buf );
    ctime_s(timebuf, 26, &buf.st_mtime);
    cout<<string(timebuf);
}

void msgShowFunction(string msgPromt,char exitCode) {
    if(exitCode == 's'){
        for(int i = 0;i<4;i++){
            system("cls");
            cout<<msgPromt;
            cout<<"Auto Exit In: "<<3-i;
            Sleep(1000);
        }
        exit(EXIT_SUCCESS);
        
    }else if(exitCode == 'f'){
        for(int i = 0;i<8;i++){
            system("cls");
            cout<<msgPromt;
            cout<<"Auto Exit In: "<<7-i;
            Sleep(1000);
        }
        exit(EXIT_FAILURE);
    }
}

int main(){

    // Variables Decleration Section
    string projectNamePrompt = "Enter Project Name: ";
    char projectName[] = "";
    // Layout's
    string indexContent = "<!DOCTYPE html><html lang=\"en-US\"><head><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"><title>LexusCreations</title><link rel=\"stylesheet\" href=\"css/style.css\"><link rel=\"shortcut icon\" href=\"favicon.ico\" type=\"image/x-icon\"> <script src=\"https://code.jquery.com/jquery-3.5.1.min.js\" integrity=\"sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=\" crossorigin=\"anonymous\"></script> <link href=\"https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap\" rel=\"stylesheet\"><link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.5.0/css/all.css\" integrity=\"sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU\" crossorigin=\"anonymous\"><link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1\" crossorigin=\"anonymous\"></head><body><div class=\"container\"> <header> <nav></nav> </header> <main></main> <footer></footer></div> <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js\" integrity=\"sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW\" crossorigin=\"anonymous\"></script> </body></html>";
    string cssContent = "*{margin: 0;padding: 0;box-sizing: border-box;scroll-behavior: smooth;transition: all 0.2s ease-in-out;}html{font-size: 16px;-webkit-font-smoothing: antialiased;}body{font-family: 'Roboto', sans-serif;background: black !important;}";
    string jsContent = "console.log(\"jsEnable's\");";
    // Error Strings
    string swwwMsg = "Something Went Wrong With ";
    string cpmMsg = "\nClose Programm Manually!\nOr\n";
    string sccMsg = "Completed Successfully!\n";

    system("cls");
    system("color 0a");

    cout<<projectNamePrompt;
    cin>>projectName;

    if(mkdir(projectName) == 0){
        cout<<string(projectName)+"\n";
        Sleep(100);
        timePrintFunction(projectName);
        Sleep(100);
        if(chdir(projectName) == 0){
            ofstream indexFile("index.html");
            cout<<"index.html\n";
            Sleep(100);
            timePrintFunction("index.html");
            Sleep(100);
            indexFile << indexContent;
            indexFile.close();
            if(mkdir("css") == 0){
                cout<<"css\n";
                Sleep(100);
                timePrintFunction("css");
                Sleep(100);
                if(chdir("css") == 0){
                    ofstream cssFile("style.css");
                    cout<<"style.css\n";
                    Sleep(100);
                    timePrintFunction("style.css");
                    Sleep(100);
                    cssFile << cssContent;
                    cssFile.close();
                    if(chdir("../") == 0){
                        if(mkdir("js") == 0){
                            cout<<"js\n";
                            Sleep(100);
                            timePrintFunction("js");
                            Sleep(100);
                            if(chdir("js") == 0){
                                ofstream jsFile("script.js");
                                cout<<"script.js\n";
                                Sleep(100);
                                timePrintFunction("script.js");
                                Sleep(100);
                                jsFile << jsContent;
                                jsFile.close();
                                msgShowFunction(sccMsg,'s');
                            }else{
                                msgShowFunction(swwwMsg+"Changing Directory To Js!"+cpmMsg,'f');
                            }
                        }else{
                            msgShowFunction(swwwMsg+"Js Folder Creation!"+cpmMsg,'f');
                        }
                    }else{
                        msgShowFunction(swwwMsg+"Changing Directory From Css To Back!"+cpmMsg,'f');
                    }
                }else{
                    msgShowFunction(swwwMsg+"Changing Directory To Css!"+cpmMsg,'f');
                }
            }else{
                msgShowFunction(swwwMsg+"Css Folder Creation!"+cpmMsg,'f');
            }
        }else{
            msgShowFunction(swwwMsg+"Changing Directory To "+projectName+cpmMsg,'f');
        }
    }else{
        msgShowFunction(swwwMsg+"Root Folder Creation!"+cpmMsg,'f');
    }
    
    system("cls");
    return 0;
}